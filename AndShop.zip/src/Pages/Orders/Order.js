import React from "react";

const Order = () => {
  return (
    <>
      <div>
        <h3>Order list</h3>
      </div>
    </>
  );
};

export default Order;
