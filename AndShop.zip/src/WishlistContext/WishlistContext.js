import { createContext } from "react";

const WishlistContext = createContext();

export default WishlistContext;
