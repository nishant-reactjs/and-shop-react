import { createContext } from "react";

const PricingContext = createContext();

export default PricingContext;
